# Simba Football Predictor

AI-powered football match prediction UI built with React.