
import { useState } from 'react';
import { Card, CardContent } from './components/ui/card';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Progress } from './components/ui/progress';
import { motion } from 'framer-motion';

export default function FootballPrediction() {
  const [teamA, setTeamA] = useState('');
  const [teamB, setTeamB] = useState('');
  const [prediction, setPrediction] = useState(null);

  const handlePredict = () => {
    const scores = [0, 1, 2, 3];
    const rand = () => scores[Math.floor(Math.random() * scores.length)];
    const scoreA = rand();
    const scoreB = rand();
    const winProb = Math.floor(Math.random() * 100);
    const drawProb = Math.floor(Math.random() * (100 - winProb));
    const loseProb = 100 - winProb - drawProb;

    setPrediction({
      score: \`\${scoreA} - \${scoreB}\`,
      probs: [winProb, drawProb, loseProb]
    });
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-xl p-6 shadow-xl rounded-2xl">
        <CardContent>
          <div className="text-center mb-6">
            <img src="/simba-logo.png" alt="Simba Kitchen Logo" className="mx-auto h-16 mb-2" />
            <h1 className="text-2xl font-bold">AI Football Match Predictor</h1>
            <p className="text-sm text-gray-500">Powered by Simba Kitchen</p>
          </div>
          <div className="grid gap-4">
            <Input placeholder="Team A Name" value={teamA} onChange={e => setTeamA(e.target.value)} />
            <Input placeholder="Team B Name" value={teamB} onChange={e => setTeamB(e.target.value)} />
            <Button onClick={handlePredict}>Predict Match</Button>
            {prediction && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-6 space-y-4">
                <h2 className="text-lg font-semibold text-center">Predicted Score</h2>
                <p className="text-center text-3xl font-bold">{teamA} {prediction.score} {teamB}</p>
                <div className="space-y-2">
                  <p>{teamA} Win Probability</p>
                  <Progress value={prediction.probs[0]} />
                  <p>Draw Probability</p>
                  <Progress value={prediction.probs[1]} />
                  <p>{teamB} Win Probability</p>
                  <Progress value={prediction.probs[2]} />
                </div>
              </motion.div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
